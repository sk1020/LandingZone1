#!/bin/bash
sudo yum update -y
sudo yum install httpd -y
sudo service httpd start 
echo "Hello, World" > index.html
